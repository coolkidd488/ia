package com.app.calculadora

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.app.calculadora.databinding.ActivityMainBinding
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var currentExpression = ""
    private var isResultShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        // Numbers
        val numberButtons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3, binding.btn4,
            binding.btn5, binding.btn6, binding.btn7, binding.btn8, binding.btn9, binding.btnDot
        )

        numberButtons.forEach { button ->
            button.setOnClickListener { onInputClick((it as Button).text.toString()) }
        }

        // Operators
        val opButtons = listOf(
            binding.btnPlus, binding.btnMinus, binding.btnMul, binding.btnDiv, binding.btnPercent
        )

        opButtons.forEach { button ->
            button.setOnClickListener { onOperatorClick((it as Button).text.toString()) }
        }

        // Actions
        binding.btnAC.setOnClickListener { clearAll() }
        binding.btnBack.setOnClickListener { backspace() }
        binding.btnEquals.setOnClickListener { calculateResult() }
    }

    private fun onInputClick(value: String) {
        if (isResultShown) {
            currentExpression = ""
            isResultShown = false
        }
        currentExpression += value
        updateDisplay()
    }

    private fun onOperatorClick(op: String) {
        if (isResultShown) {
            isResultShown = false
        }
        // Avoid double operators or starting with operator (except minus)
        if (currentExpression.isNotEmpty()) {
            val lastChar = currentExpression.last()
            if (isOperator(lastChar.toString())) {
                 // Replace operator
                 currentExpression = currentExpression.dropLast(1) + op
            } else {
                currentExpression += op
            }
        }
        updateDisplay()
    }

    private fun isOperator(char: String): Boolean {
        return char == "+" || char == "-" || char == "*" || char == "/" || char == "%"
    }

    private fun clearAll() {
        currentExpression = ""
        updateDisplay(overrideText = "0")
    }

    private fun backspace() {
        if (currentExpression.isNotEmpty()) {
            currentExpression = currentExpression.dropLast(1)
            updateDisplay()
        }
    }

    private fun updateDisplay(overrideText: String? = null) {
        binding.tvResult.text = overrideText ?: if (currentExpression.isEmpty()) "0" else currentExpression
    }

    private fun calculateResult() {
        try {
            if (currentExpression.isEmpty()) return

            // Replace visual operators with standard ones if needed (e.g. x to *)
            val expressionToParse = currentExpression.replace("%", "/100")
            
            val result = ExpressionEvaluator.eval(expressionToParse)
            
            // Format result to remove trailing zeros
            val df = DecimalFormat("#.##########")
            currentExpression = df.format(result).replace(",", ".") // Ensure dot for next calc
            
            updateDisplay()
            isResultShown = true
        } catch (e: Exception) {
            updateDisplay(overrideText = "Erro")
            isResultShown = true
        }
    }

    // Simple recursive descent parser helper object to avoid external dependencies
    object ExpressionEvaluator {
        fun eval(str: String): Double {
            return object : Any() {
                var pos = -1
                var ch = 0
                fun nextChar() {
                    ch = if (++pos < str.length) str[pos].code else -1
                }

                fun eat(charToEat: Int): Boolean {
                    while (ch == ' '.code) nextChar()
                    if (ch == charToEat) {
                        nextChar()
                        return true
                    }
                    return false
                }

                fun parse(): Double {
                    nextChar()
                    val x = parseExpression()
                    if (pos < str.length) throw RuntimeException("Unexpected: " + ch.toChar())
                    return x
                }

                fun parseExpression(): Double {
                    var x = parseTerm()
                    while (true) {
                        if (eat('+'.code)) x += parseTerm()
                        else if (eat('-'.code)) x -= parseTerm()
                        else return x
                    }
                }

                fun parseTerm(): Double {
                    var x = parseFactor()
                    while (true) {
                        if (eat('*'.code)) x *= parseFactor()
                        else if (eat('/'.code)) x /= parseFactor()
                        else return x
                    }
                }

                fun parseFactor(): Double {
                    if (eat('+'.code)) return parseFactor()
                    if (eat('-'.code)) return -parseFactor()
                    var x: Double
                    val startPos = pos
                    if (eat('('.code)) {
                        x = parseExpression()
                        eat(')'.code)
                    } else if (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) {
                        while (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) nextChar()
                        x = str.substring(startPos, pos).toDouble()
                    } else {
                        throw RuntimeException("Unexpected: " + ch.toChar())
                    }
                    return x
                }
            }.parse()
        }
    }
}