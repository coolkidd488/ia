package com.example.simplecalculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.simplecalculator.databinding.ActivityMainBinding
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var currentInput = ""
    private var operator: String? = null
    private var firstOperand: Double? = null
    private var isNewOperation = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        val numberButtons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3, binding.btn4,
            binding.btn5, binding.btn6, binding.btn7, binding.btn8, binding.btn9
        )

        numberButtons.forEach { button ->
            button.setOnClickListener { onDigitClick(button) }
        }

        binding.btnDot.setOnClickListener { onDotClick() }
        
        val opButtons = mapOf(
            binding.btnPlus to "+",
            binding.btnMinus to "-",
            binding.btnMultiply to "*",
            binding.btnDivide to "/"
        )

        opButtons.forEach { (btn, op) ->
            btn.setOnClickListener { onOperatorClick(op) }
        }

        binding.btnEqual.setOnClickListener { onEqualClick() }
        binding.btnAC.setOnClickListener { onClearClick() }
        binding.btnBackspace.setOnClickListener { onBackspaceClick() }
    }

    private fun onDigitClick(view: View) {
        if (isNewOperation) {
            currentInput = ""
            isNewOperation = false
        }
        
        val button = view as Button
        currentInput += button.text.toString()
        updateDisplay()
    }

    private fun onDotClick() {
        if (isNewOperation) {
            currentInput = "0."
            isNewOperation = false
        } else if (!currentInput.contains(".")) {
            currentInput += "."
        }
        updateDisplay()
    }

    private fun onOperatorClick(op: String) {
        if (currentInput.isNotEmpty()) {
            // If we already have an operator and a new input, calculate first
            if (operator != null && !isNewOperation) {
                onEqualClick()
            }
            firstOperand = currentInput.toDoubleOrNull()
            operator = op
            isNewOperation = true
            updateExpressionDisplay("$currentInput $op")
        }
    }

    private fun onEqualClick() {
        if (firstOperand != null && operator != null && currentInput.isNotEmpty()) {
            val secondOperand = currentInput.toDoubleOrNull()
            if (secondOperand != null) {
                var result = 0.0
                var error = false

                when (operator) {
                    "+" -> result = firstOperand!! + secondOperand
                    "-" -> result = firstOperand!! - secondOperand
                    "*" -> result = firstOperand!! * secondOperand
                    "/" -> {
                        if (secondOperand == 0.0) {
                            error = true
                        } else {
                            result = firstOperand!! / secondOperand
                        }
                    }
                }

                if (error) {
                    currentInput = "Error"
                    isNewOperation = true
                } else {
                    // Remove trailing .0 for integers
                    currentInput = DecimalFormat("0.##########").format(result)
                    firstOperand = null
                    operator = null
                    isNewOperation = true
                }
                updateExpressionDisplay("")
                updateDisplay()
            }
        }
    }

    private fun onClearClick() {
        currentInput = "0"
        firstOperand = null
        operator = null
        isNewOperation = true
        updateDisplay()
        updateExpressionDisplay("")
    }

    private fun onBackspaceClick() {
        if (!isNewOperation && currentInput.isNotEmpty()) {
            currentInput = currentInput.dropLast(1)
            if (currentInput.isEmpty()) {
                currentInput = "0"
                isNewOperation = true
            }
            updateDisplay()
        }
    }

    private fun updateDisplay() {
        binding.tvResult.text = currentInput
    }
    
    private fun updateExpressionDisplay(text: String) {
        binding.tvExpression.text = text
    }
}